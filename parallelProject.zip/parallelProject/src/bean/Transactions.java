package bean;

public class Transactions {
private String debitAccountNumber;
private String creditAccountNumber;
private double debit;
private double credit;
static int tranNum=1;
 private String tranNumber; 


public Transactions(String tranNumber,String creditAccountNumber, double credit) {
	super();
	this.creditAccountNumber = creditAccountNumber;
	this.credit = credit;
	this.tranNumber = autoGenerateAccount();
	
}
public Transactions(String tranNumber,String debitAccountNumber, String creditAccountNumber, double debit, double credit) {
	super();
	this.debitAccountNumber = debitAccountNumber;
	this.creditAccountNumber = creditAccountNumber;
	this.debit = debit;
	this.credit = credit;
	this.tranNumber = autoGenerateAccount();
	
}
public String autoGenerateAccount() {
	String acNumber ="T"+tranNum;
	tranNum++;
	return acNumber;
	
}


public String getTranNumber() {
	return tranNumber;
}
public void setTranNumber(String tranNumber) {
	this.tranNumber = tranNumber;
}
public String getDebitAccountNumber() {
	return debitAccountNumber;
}
public void setDebitAccountNumber(String debitAccountNumber) {
	this.debitAccountNumber = debitAccountNumber;
}
public String getCreditAccountNumber() {
	return creditAccountNumber;
}
public void setCreditAccountNumber(String creditAccountNumber) {
	this.creditAccountNumber = creditAccountNumber;
}
public double getDebit() {
	return debit;
}
public void setDebit(double debit) {
	this.debit = debit;
}
public double getCredit() {
	return credit;
}
public void setCredit(double credit) {
	this.credit = credit;
}
@Override
public String toString() {
	return "Transactions [debitAccountNumber=" + debitAccountNumber + ", creditAccountNumber=" + creditAccountNumber
			+ ", debit=" + debit + ", credit=" + credit + "]";
}

}
