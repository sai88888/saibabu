package service;

public class MyException extends Exception {
 public void MyException() {
	 System.out.println("please enter a number");
 }
}
