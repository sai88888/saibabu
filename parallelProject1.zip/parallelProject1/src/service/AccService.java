package service;
import java.awt.List;
import java.util.HashMap;
import java.util.Map;

import bean.Customer;
import bean.Transactions;
import dao.StorageDAO;
public class AccService {
	
	
StorageDAO daObj =new StorageDAO();
Customer accShowBalObj = new Customer();

	public void storeData(Customer obj) {
		daObj.storingMethod(obj);
	}
	
	public void storeTransactions(Transactions obj) {
		daObj.TransactionstoringMethod(obj);
	}
	
		public Customer  retrieveData(String accountNumber) {
			Customer deeObj = daObj.retrieveData(accountNumber);
			return deeObj;
			
			}
			
		public HashMap<String, Transactions>  retrieveTransaction(String accountNumber) {
			HashMap<String, Transactions> tranObj = daObj.retrieveTransactions(accountNumber);
			return tranObj;
			
			}
}

