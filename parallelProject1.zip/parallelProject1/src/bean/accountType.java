package bean;

public enum accountType {
	
		SAVINGS,CURRENT;
	
}
