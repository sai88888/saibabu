package bean;

public class Account {
	
static int accNum = 1;	
private String accountNum;
private String accountType;
private double balance;



public Account(String accountNum, String accountType,double balance) {
	super();
	this.accountNum = autoGenerateAccount();
	
	this.accountType = accountType;
	this.balance = balance;
}

public String autoGenerateAccount() {
	String acNumber ="A"+accNum;
	accNum++;
	return acNumber;
	
}
public double getBalance() {
	return balance;
}

public void setBalance(double balance) {
	this.balance = balance;
}
public String getAccountNum() {
	return accountNum;
}
public void setAccountNum(String accountNum) {
	this.accountNum = accountNum;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}

@Override
public String toString() {
	return "Account [accountNum=" + accountNum + ", accountType=" + accountType + ", balance=" + balance + "]";
}


}
